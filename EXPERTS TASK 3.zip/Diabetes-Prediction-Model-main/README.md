# Diabetes-Prediction-Model
A machine learning model developed to predict the likelihood of diabetes in patients based on medical features such as age, BMI, blood pressure, glucose levels, and insulin. Trained using Diabetes Dataset with classification algorithms like Logistic Regression to achieve accurate predictions.
